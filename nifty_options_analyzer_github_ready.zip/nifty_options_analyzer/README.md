# NIFTY Options Analyzer

Android Flutter app for NIFTY options analysis using the official INDstocks API.

## Features

- NIFTY option-chain view
- Multiple upcoming expiries
- One-minute candle table for a selected option
- Minute close and volume
- Volume direction arrows compared with the previous minute
- Multi-expiry prediction/market-bias analysis
- CE/PE volume, OI and OI-change analysis
- INDstocks API token entered inside the app and stored locally on the phone
- No Yahoo Finance
- No Chartink
- No order placement

## GitHub Actions build

This repository is designed to build the APK directly on GitHub Actions. The workflow is stored at:

`.github/workflows/build-options-apk.yml`

GitHub Actions will:

1. Check out the repository.
2. Install stable Flutter.
3. Generate the Android platform files.
4. Install dependencies.
5. Run `flutter analyze`.
6. Build a release APK.
7. Upload `app-release.apk` as a workflow artifact.

The APK can be downloaded from the completed workflow run under **Artifacts**.

## API token security

Do **not** put the INDstocks API token in this repository or in source code. Enter it through the app's **INDstocks Token** menu. The app stores it locally using Android app preferences.

## Important

The prediction page provides an analytical market-bias signal, not a guaranteed forecast or trading recommendation. Verify live data and API response formats before using the app for real-money decisions.
