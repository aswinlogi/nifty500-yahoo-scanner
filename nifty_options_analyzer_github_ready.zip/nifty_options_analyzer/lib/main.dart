
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const String apiBase = 'https://api.indstocks.com';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NiftyOptionsApp());
}

class OptionContract {
  final String securityId;
  final String tradingSymbol;
  final String expiry;
  final double strike;
  final String type;
  final double ltp;
  final double prevClose;
  final double oi;
  final double prevOi;
  final double volume;
  final double iv;
  final double? delta;
  final double? gamma;
  final double? theta;
  final double? vega;

  const OptionContract({
    required this.securityId,
    required this.tradingSymbol,
    required this.expiry,
    required this.strike,
    required this.type,
    required this.ltp,
    required this.prevClose,
    required this.oi,
    required this.prevOi,
    required this.volume,
    required this.iv,
    this.delta,
    this.gamma,
    this.theta,
    this.vega,
  });

  double get oiChange => oi - prevOi;
  double get priceChange => ltp - prevClose;
}

class Candle {
  final DateTime time;
  final double close;
  final double volume;
  const Candle(this.time, this.close, this.volume);
}

class ExpiryBias {
  final String expiry;
  final double score;
  final double ceVolume;
  final double peVolume;
  final double ceOiChange;
  final double peOiChange;
  final double underlying;
  final String label;

  const ExpiryBias({
    required this.expiry,
    required this.score,
    required this.ceVolume,
    required this.peVolume,
    required this.ceOiChange,
    required this.peOiChange,
    required this.underlying,
    required this.label,
  });
}

class IndstocksApi {
  final String token;

  IndstocksApi(this.token);

  Future<dynamic> getJson(String path, [Map<String, String>? query]) async {
    final uri = Uri.parse('$apiBase$path').replace(queryParameters: query);
    final response = await http.get(
      uri,
      headers: {'Authorization': token.trim()},
    ).timeout(const Duration(seconds: 20));

    dynamic body;
    try {
      body = jsonDecode(response.body);
    } catch (_) {
      throw Exception('Invalid response from INDstocks (${response.statusCode})');
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final msg = body is Map
          ? (body['debug_info'] ?? body['message'] ?? body['error'] ?? 'API error')
          : 'API error ${response.statusCode}';
      throw Exception(msg.toString());
    }
    return body;
  }

  Future<List<String>> expiries() async {
    final body = await getJson('/market/instruments/expiries', {
      'underlying': 'NIFTY',
      'segment': 'DERIVATIVE',
    });
    final data = body['data'];
    if (data is! List) return [];
    return data.map((e) => e.toString()).toList();
  }

  Future<List<OptionContract>> chain(String expiry, {int strikeCount = 20}) async {
    final body = await getJson('/market/option-chain', {
      'exchange': 'NSE',
      'segment': 'INDEX',
      'underlying-scrip': '40000001',
      'expiry': expiry,
      'strike_count': '$strikeCount',
    });
    final data = body['data'];
    if (data is! Map) return [];
    final strikes = data['strikes'];
    if (strikes is! Map) return [];

    final result = <OptionContract>[];
    for (final entry in strikes.entries) {
      final strike = double.tryParse(entry.key.toString());
      if (strike == null || entry.value is! Map) continue;
      final legs = entry.value as Map;
      for (final type in const ['ce', 'pe']) {
        final raw = legs[type];
        if (raw is! Map) continue;
        double n(dynamic v) => v is num ? v.toDouble() : double.tryParse('$v') ?? 0;
        double? nullable(dynamic v) => v is num ? v.toDouble() : double.tryParse('$v');
        final greeks = raw['greeks'] is Map ? raw['greeks'] as Map : const {};
        result.add(OptionContract(
          securityId: '${raw['security_id'] ?? ''}',
          tradingSymbol: '${raw['trading_symbol'] ?? ''}',
          expiry: expiry,
          strike: strike,
          type: type.toUpperCase(),
          ltp: n(raw['last_price']),
          prevClose: n(raw['previous_close_price']),
          oi: n(raw['oi']),
          prevOi: n(raw['previous_oi']),
          volume: n(raw['volume']),
          iv: n(raw['iv']),
          delta: nullable(greeks['delta']),
          gamma: nullable(greeks['gamma']),
          theta: nullable(greeks['theta']),
          vega: nullable(greeks['vega']),
        ));
      }
    }
    result.sort((a, b) {
      final s = a.strike.compareTo(b.strike);
      return s != 0 ? s : a.type.compareTo(b.type);
    });
    return result;
  }

  Future<List<Candle>> oneMinuteCandles(String securityId, DateTime day) async {
    final istStart = DateTime(day.year, day.month, day.day, 9, 15);
    final now = DateTime.now();
    final end = now.isAfter(istStart) ? now : istStart.add(const Duration(minutes: 1));
    final body = await getJson('/market/historical/1minute', {
      'scrip-codes': 'NFO_$securityId',
      'start_time': '${istStart.millisecondsSinceEpoch}',
      'end_time': '${end.millisecondsSinceEpoch}',
    });

    final data = body['data'];
    if (data is! Map) return [];
    final item = data['NFO_$securityId'];
    if (item is! Map || item['candles'] is! List) return [];

    final candles = <Candle>[];
    for (final raw in item['candles']) {
      if (raw is! Map) continue;
      final ts = raw['ts'];
      if (ts is! num) continue;
      final t = DateTime.fromMillisecondsSinceEpoch(ts.toInt() * 1000, isUtc: true)
          .toLocal();
      final close = raw['c'];
      final volume = raw['v'];
      if (close is num && volume is num) {
        candles.add(Candle(t, close.toDouble(), volume.toDouble()));
      }
    }
    candles.sort((a, b) => a.time.compareTo(b.time));

    // Do not display the currently incomplete minute candle.
    final cutoff = DateTime.now().subtract(const Duration(minutes: 1));
    return candles.where((c) => c.time.isBefore(cutoff)).toList();
  }
}

class NiftyOptionsApp extends StatelessWidget {
  const NiftyOptionsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NIFTY Options Analyzer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String token = '';
  IndstocksApi? api;
  bool loading = false;
  String status = 'Enter your INDstocks access token';
  List<String> expiries = [];
  String? selectedExpiry;
  List<OptionContract> contracts = [];
  OptionContract? selectedContract;
  List<Candle> candles = [];
  Timer? timer;
  int tab = 0;

  @override
  void initState() {
    super.initState();
    _loadToken();
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> _loadToken() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('indstocks_token') ?? '';
    if (saved.isNotEmpty) {
      setState(() {
        token = saved;
        api = IndstocksApi(saved);
      });
      await _loadExpiries();
    }
  }

  Future<void> _saveToken(String value) async {
    final clean = value.trim();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('indstocks_token', clean);
    setState(() {
      token = clean;
      api = IndstocksApi(clean);
      status = 'Token saved on this device';
    });
    await _loadExpiries();
  }

  bool _marketOpen() {
    final now = DateTime.now();
    if (now.weekday > DateTime.friday) return false;
    final open = DateTime(now.year, now.month, now.day, 9, 15);
    final close = DateTime(now.year, now.month, now.day, 15, 30);
    return !now.isBefore(open) && now.isBefore(close);
  }

  Future<void> _loadExpiries() async {
    if (api == null) return;
    setState(() => loading = true);
    try {
      final e = await api!.expiries();
      setState(() {
        expiries = e;
        selectedExpiry = e.isNotEmpty ? e.first : null;
        status = e.isEmpty ? 'No upcoming NIFTY expiries returned' : 'Ready';
      });
      if (selectedExpiry != null) await _loadChain();
    } catch (e) {
      setState(() => status = 'Expiry error: $e');
    } finally {
      setState(() => loading = false);
    }
  }

  Future<void> _loadChain() async {
    if (api == null || selectedExpiry == null) return;
    setState(() => loading = true);
    try {
      final c = await api!.chain(selectedExpiry!, strikeCount: 25);
      setState(() {
        contracts = c;
        if (selectedContract != null) {
          final match = c.where((x) =>
              x.securityId == selectedContract!.securityId &&
              x.type == selectedContract!.type);
          selectedContract = match.isNotEmpty ? match.first : null;
        }
        status = 'Loaded ${c.length} option legs • ${selectedExpiry!}';
      });
      if (selectedContract != null) await _refreshCandles();
    } catch (e) {
      setState(() => status = 'Chain error: $e');
    } finally {
      setState(() => loading = false);
    }
  }

  Future<void> _refreshCandles() async {
    final c = selectedContract;
    if (api == null || c == null) return;
    try {
      final rows = await api!.oneMinuteCandles(c.securityId, DateTime.now());
      if (mounted) setState(() => candles = rows);
    } catch (e) {
      if (mounted) setState(() => status = '1-minute data error: $e');
    }
  }

  void _startLive() {
    timer?.cancel();
    timer = Timer.periodic(const Duration(minutes: 1), (_) async {
      if (_marketOpen()) {
        await _loadChain();
        await _refreshCandles();
      }
    });
  }

  void _selectContract(OptionContract c) {
    setState(() {
      selectedContract = c;
      candles = [];
      tab = 0;
    });
    _refreshCandles();
    _startLive();
  }

  Future<void> _tokenDialog() async {
    final controller = TextEditingController(text: token);
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('INDstocks access token'),
        content: TextField(
          controller: controller,
          obscureText: true,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: 'Paste your access token',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (result != null && result.trim().isNotEmpty) {
      await _saveToken(result);
    }
  }

  List<OptionContract> get calls =>
      contracts.where((x) => x.type == 'CE').toList();
  List<OptionContract> get puts =>
      contracts.where((x) => x.type == 'PE').toList();

  Future<List<ExpiryBias>> _predict() async {
    if (api == null || expiries.isEmpty) return [];
    final list = expiries.take(6).toList();
    final out = <ExpiryBias>[];
    for (final e in list) {
      try {
        final chain = await api!.chain(e, strikeCount: 10);
        if (chain.isEmpty) continue;
        final ce = chain.where((x) => x.type == 'CE').toList();
        final pe = chain.where((x) => x.type == 'PE').toList();
        final ceVol = ce.fold<double>(0, (s, x) => s + x.volume);
        final peVol = pe.fold<double>(0, (s, x) => s + x.volume);
        final ceOi = ce.fold<double>(0, (s, x) => s + x.oiChange);
        final peOi = pe.fold<double>(0, (s, x) => s + x.oiChange);
        final ltp = chain.isNotEmpty ? chain.first.ltp : 0;

        double score = 0;
        if (peOi > ceOi) score += 1.5;
        if (ceOi < 0 && peOi > 0) score += 2;
        if (ceVol > 0 && peVol > ceVol * 1.08) score += 1;
        if (ceVol > 0 && ceVol > peVol * 1.08) score -= 1;
        if (ceOi > 0 && ceVol > peVol) score -= 1;
        final label = score >= 2 ? 'BULLISH' : score <= -2 ? 'BEARISH' : 'NEUTRAL';

        out.add(ExpiryBias(
          expiry: e,
          score: score,
          ceVolume: ceVol,
          peVolume: peVol,
          ceOiChange: ceOi,
          peOiChange: peOi,
          underlying: ltp,
          label: label,
        ));
      } catch (_) {}
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('NIFTY Options Analyzer'),
        actions: [
          IconButton(
            tooltip: 'API token',
            onPressed: _tokenDialog,
            icon: const Icon(Icons.key),
          ),
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'prediction') setState(() => tab = 2);
              if (v == 'refresh') _loadChain();
              if (v == 'token') _tokenDialog();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'prediction', child: Text('Prediction')),
              PopupMenuItem(value: 'refresh', child: Text('Refresh option chain')),
              PopupMenuItem(value: 'token', child: Text('INDstocks token')),
            ],
          ),
        ],
      ),
      body: token.isEmpty ? _setup() : _body(),
    );
  }

  Widget _setup() => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.candlestick_chart, size: 64),
              const SizedBox(height: 16),
              const Text('NIFTY Options Analyzer',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              const Text(
                'Enter your INDstocks access token. It is stored only on this phone.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: _tokenDialog,
                icon: const Icon(Icons.key),
                label: const Text('Enter access token'),
              ),
            ],
          ),
        ),
      );

  Widget _body() {
    return Column(
      children: [
        Material(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: selectedExpiry,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'NIFTY expiry',
                      border: OutlineInputBorder(),
                    ),
                    items: expiries
                        .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                        .toList(),
                    onChanged: (v) async {
                      setState(() => selectedExpiry = v);
                      await _loadChain();
                    },
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: loading ? null : _loadChain,
                  icon: const Icon(Icons.refresh),
                ),
              ],
            ),
          ),
        ),
        if (status.isNotEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(status, style: Theme.of(context).textTheme.bodySmall),
            ),
          ),
        Expanded(
          child: IndexedStack(
            index: tab,
            children: [
              _minutePage(),
              _chainPage(),
              _predictionPage(),
            ],
          ),
        ),
        NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (v) => setState(() => tab = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.view_list), label: '1-Min'),
            NavigationDestination(icon: Icon(Icons.table_chart), label: 'Chain'),
            NavigationDestination(icon: Icon(Icons.insights), label: 'Prediction'),
          ],
        ),
      ],
    );
  }

  Widget _minutePage() {
    final c = selectedContract;
    if (c == null) {
      return const Center(child: Text('Select a CE or PE from Chain.'));
    }
    return Column(
      children: [
        Card(
          margin: const EdgeInsets.fromLTRB(10, 4, 10, 8),
          child: ListTile(
            title: Text('${c.strike.toStringAsFixed(0)} ${c.type}'),
            subtitle: Text('${c.expiry} • ${c.tradingSymbol}'),
            trailing: Text('₹${c.ltp.toStringAsFixed(2)}',
                style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
        ),
        Expanded(
          child: candles.isEmpty
              ? const Center(child: Text('Waiting for 1-minute candles...'))
              : ListView.builder(
                  itemCount: candles.length,
                  itemBuilder: (_, i) {
                    final row = candles[i];
                    final prev = i == 0 ? null : candles[i - 1];
                    final up = prev == null || row.volume > prev.volume;
                    final down = prev != null && row.volume < prev.volume;
                    final arrow = up ? '↑' : down ? '↓' : '→';
                    final color = up
                        ? Colors.green
                        : down
                            ? Colors.red
                            : Colors.amber;
                    return ListTile(
                      dense: true,
                      leading: SizedBox(
                        width: 62,
                        child: Text(
                          '${row.time.hour.toString().padLeft(2, '0')}:${row.time.minute.toString().padLeft(2, '0')}',
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ),
                      title: Text('₹${row.close.toStringAsFixed(2)}'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(_fmt(row.volume)),
                          const SizedBox(width: 10),
                          Text(arrow,
                              style: TextStyle(
                                  color: color,
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _chainPage() {
    if (contracts.isEmpty) {
      return const Center(child: Text('No option chain loaded.'));
    }
    return ListView(
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(12, 8, 12, 4),
          child: Text('Calls • tap a contract for 1-minute data',
              style: TextStyle(fontWeight: FontWeight.bold)),
        ),
        ...calls.map(_contractTile),
        const Divider(),
        const Padding(
          padding: EdgeInsets.fromLTRB(12, 8, 12, 4),
          child: Text('Puts • tap a contract for 1-minute data',
              style: TextStyle(fontWeight: FontWeight.bold)),
        ),
        ...puts.map(_contractTile),
      ],
    );
  }

  Widget _contractTile(OptionContract c) {
    final selected = selectedContract?.securityId == c.securityId;
    final oiUp = c.oiChange >= 0;
    return ListTile(
      selected: selected,
      onTap: () => _selectContract(c),
      title: Text('${c.strike.toStringAsFixed(0)} ${c.type}  ₹${c.ltp.toStringAsFixed(2)}'),
      subtitle: Text(
        'OI ${_fmt(c.oi)}  ΔOI ${c.oiChange >= 0 ? '+' : ''}${_fmt(c.oiChange)}  Vol ${_fmt(c.volume)}  IV ${c.iv.toStringAsFixed(1)}%',
      ),
      trailing: Text(
        oiUp ? '↑ OI' : '↓ OI',
        style: TextStyle(color: oiUp ? Colors.green : Colors.red),
      ),
    );
  }

  Widget _predictionPage() {
    return FutureBuilder<List<ExpiryBias>>(
      future: _predict(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        final rows = snap.data ?? [];
        if (rows.isEmpty) {
          return const Center(child: Text('Prediction data unavailable.'));
        }
        final avg = rows.fold<double>(0, (s, x) => s + x.score) / rows.length;
        final overall = avg >= 1 ? 'BULLISH' : avg <= -1 ? 'BEARISH' : 'NEUTRAL';
        final color = overall == 'BULLISH'
            ? Colors.green
            : overall == 'BEARISH'
                ? Colors.red
                : Colors.amber;
        return ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Card(
              child: ListTile(
                leading: Icon(Icons.insights, color: color, size: 36),
                title: Text('Market bias: $overall',
                    style: TextStyle(color: color, fontWeight: FontWeight.bold)),
                subtitle: Text(
                    'Model score ${avg.toStringAsFixed(1)} across ${rows.length} upcoming expiries. This is an analytical signal, not a guaranteed prediction.'),
              ),
            ),
            const SizedBox(height: 8),
            const Text('Multi-expiry comparison',
                style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            ...rows.map((r) => Card(
                  child: ListTile(
                    title: Text(r.expiry),
                    subtitle: Text(
                      'CE Vol ${_fmt(r.ceVolume)} • PE Vol ${_fmt(r.peVolume)}\n'
                      'CE ΔOI ${_fmt(r.ceOiChange)} • PE ΔOI ${_fmt(r.peOiChange)}',
                    ),
                    trailing: Text(r.label,
                        style: TextStyle(
                            color: r.label == 'BULLISH'
                                ? Colors.green
                                : r.label == 'BEARISH'
                                    ? Colors.red
                                    : Colors.amber,
                            fontWeight: FontWeight.bold)),
                  ),
                )),
          ],
        );
      },
    );
  }

  String _fmt(double v) {
    final a = v.abs();
    if (a >= 10000000) return '${(v / 10000000).toStringAsFixed(1)}Cr';
    if (a >= 100000) return '${(v / 100000).toStringAsFixed(1)}L';
    if (a >= 1000) return '${(v / 1000).toStringAsFixed(1)}K';
    return v.toStringAsFixed(0);
  }
}
